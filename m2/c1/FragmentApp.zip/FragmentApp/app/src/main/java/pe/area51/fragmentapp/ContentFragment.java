package pe.area51.fragmentapp;

import android.app.Fragment;

public class ContentFragment extends Fragment {


}
